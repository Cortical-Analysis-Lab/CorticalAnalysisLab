# High-school research files for Codex in Codespaces

This ZIP is a standalone file update, not a Git bundle. It requires no earlier commit or bundle. It contains the 89-program high-school discovery tool, source evidence and review decisions.

Work on Summer-REU-Database. Read the repository AGENTS.md first. Extract into a temporary directory and compare database/discovery/high-school with the existing branch before copying. Preserve existing edits and reconcile differences; do not reset the branch or overwrite unrelated work. If this folder is absent, add it. All project files in this archive belong under database/discovery/high-school/ at the repository root.

Run python3 database/discovery/high-school/build.py and git diff --check. Confirm 89 program records, 7 neuroscience-tagged records, 17 records with summer-linked aid, and 4 unresolved leads. Open database/discovery/high-school/index.html and check search and filters. Source files and the generated viewer are included; no package installation or external service is required to use the viewer.

Commit the integrated files on Summer-REU-Database, not the ZIP or any bundle. Keep main, undergraduate data, and deployment configuration unchanged. Do not push or publish unless the user requests it.

The README's Git-bundle import section describes an alternative delivery method and is unnecessary for this ZIP. This ZIP updates only the high-school tool; it does not import any missing undergraduate updates.
