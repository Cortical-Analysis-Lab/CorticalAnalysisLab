"""Build the offline viewer and validate the reviewed discovery records."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
data=json.loads((root/'programs.json').read_text())
records=data['programs']
assert len({p['id'] for p in records})==len(records), 'Duplicate IDs'
assert len({p['url'] for p in records})==len(records), 'Review shared URLs for duplicates'
ids={p['id'] for p in records}
canonical=lambda u:u.lower().rstrip('/')
assert len({canonical(p['url']) for p in records})==len(records), 'Duplicate canonical program URLs'
for p in records:
    assert p['country'] not in data['policy']['blockedHostCountries']
    assert p['season']=='Summer'
    assert p['summerLinkedAid']['status'] in {'available','unknown','not_available'}
    if p['summerLinkedAid']['status']=='available':
        assert p['summerLinkedAid'].get('sourceUrl') in p['sources'], 'Aid needs attached program evidence'
    assert p['id'] not in p['relatedPrograms']
    assert p['name'] and p['eligibility'] and p['sources']
    assert all(u.startswith('https://') for u in p['sources'])
    assert all(r in {x['id'] for x in records} for r in p['relatedPrograms'])
encoded=json.dumps(data).replace('<','\\u003c')
(root/'index.html').write_text((root/'viewer-template.html').read_text().replace('__DATA__',encoded))
print(f'Built viewer for {len(records)} programs; {len(data["reviewQueue"])} unverified leads excluded.')
