# High school summer research discovery

Open `index.html` directly in a browser. Search programs and fields; filter research area (including Neuroscience), state, costs, housing and summer-linked financial support. Export the filtered records as JSON. The Find more section generates live searches using research, internship, fellowship and summer research scholarship terminology. Results are not automatically imported or verified.

## Coverage and evidence

89 distinct program listings, checked September 21, 2026. The follow-up review individually evaluated all 33 previous leads: 17 added, 12 excluded for scope/eligibility, one duplicate linked to Los Alamos, and three still unresolved (LaGuardia, Hutton, ICLEM). New-source discovery added another 14 programs. One new lead (Bronx River EELS) needs timeline confirmation, giving four total unresolved leads outside the count. `lead-review.json` contains every decision and its evidence; the offline viewer displays the original 33-lead audit.

Seven programs explicitly carry the Neuroscience tag: BU RISE, George Mason ASSIP, Illinois Young Scholars STEMM, Science Mentorship Institute NMP, Columbia BRAINYAC, BioBus Junior Scientist, and UPMC Hillman Academy. Neuro tags are based on program descriptions or documented research sites, not the entire institution's portfolio. Seventeen listings have documented summer-linked scholarships, fee waivers, conditional stipends or travel assistance. Ordinary pay is recorded separately. Support never creates an additional opportunity count.

The expansion reviewed Pathways to Science's high-school program profiles, Fred Hutch's internship directory, NYC Science Research Mentoring Consortium profiles, and linked university, hospital, government-laboratory and nonprofit sources. Direct host pages take precedence over directories. Additional discovery used the official BioBus referral list, Weill Cornell outreach directory, Tuskegee summer-program directory, University of Florida CPET directory, and direct sources at Iowa, Salk, Hofstra and UPMC Hillman. Moved URLs were repaired through host navigation. Several old directory leads had changed eligibility or represented academic-year work. The source ledger records available HTTP results and source hashes, not a guarantee that every link was accessible. Program-network records and historical reports have explicit evidence labels. Some host pages blocked retrieval; a documented program is not assumed discontinued because a page is inaccessible.

This is a broad US-focused review, not a complete national or international inventory or an all-50-state census. One documented JSEP field program in Greenland is included, with directory-supported eligibility explicitly labeled as needing current host confirmation. Search-engine results were unreliable; discovery relied primarily on directories and direct institution pages. Unresolved candidates remain in the review queue. A lead is not necessarily a distinct program: identity and eligibility must be checked before admission. Fields, current dates, costs, citizenship and housing remain unknown unless supported. Tags describe documented program content, not the host institution's entire research portfolio. A neuroscience tag does not guarantee a neuroscience project in every cycle.

## Identity and eligibility

One stable ID per program across annual cycles. BU RISE tracks share a listing. UCSC's renamed Scholar Immersion Program retains its former name as an alias. Rockefeller LAB Jumpstart's summer component enters SSRP and is attached to that listing. Cornell/MSK High School Catalyst is linked as a named NY Bioforce placement through the same student application; MCC/EIPM and MSK Summer Student Program have distinct admissions and remain separate. Separate UCSB programs, Science Mentorship Institute subject programs, CUNY campus admissions routes and Stony Brook programs are linked as related. Mentor slots, campus tracks with common admissions, annual cycles and scholarships do not inflate counts.

High-school eligibility is independent of the SHU undergraduate catalog. Local-only and partner-school programs are retained with restrictions. Several require spring preparation; descriptions say so. Closed programs remain discoverable. JAX's current undergraduate-only admissions override older high-school directories. NASA's generic OSTEM listing is not assumed high-school eligible. Standalone awards, general college scholarships and unsupported enrichment-only programs are excluded. The existing Israel host/placement exclusion is retained.

Unknown values display as N/A. Historical cycle amounts and deadlines do not become current-year promises. Some descriptions retain cycle-specific context because host pages differ. Consult the linked host before applying. Housing availability is distinct from housing funding and meal coverage.

## Updating

Edit `programs.json`, attach evidence and checked dates, review aliases and related programs, and run:

```bash
python3 database/discovery/high-school/build.py
```

`source-review.json` preserves link-review metadata; source page bodies are not redistributed. `index.html` is generated from `viewer-template.html` and `programs.json`. This discovery folder is separate from the undergraduate snapshot and accepted SQLite catalog; publication configuration is unchanged.

## Import the refreshed bundle

The corrected `high-school-research-update.bundle` is self-contained: it contains the full history reachable from `Summer-REU-Database`, including the earlier undergraduate audit commit and all high-school updates. No earlier bundle is required. The bundle is verified by importing it into an empty repository.

For Codex in Codespaces: import the bundle objects, compare its branch with the existing `Summer-REU-Database`, and integrate the update while preserving existing commits and uncommitted work. A prior upload commit may mean the branches have diverged; inspect and merge deliberately rather than resetting the branch. Do not modify `main` or publish the website. Validate the 89-program high-school viewer after integration. Uploading or committing the bundle file alone does not import the history inside it.

## Notable verification corrections

- Michigan State HSHSP is retained with a **no 2026 program** notice, rather than excluded for the pause.
- USC BUGS Jr. is the high-school program, with an $800 2026 completion stipend; undergraduate BUGS funding does not apply.
- UW INSIGHT high-school participants pay tuition and may seek limited scholarships; the undergraduate stipend is not inherited.
- Current Wave Hill eligibility says age 15, superseding the network's older age-16 description.
- UF SSTP housing is included in the program fee, but daily meals are not.
- PROMYS includes first-year exploration labs and returning-student mentored original research; these are not equivalent experiences.
- MathILy-EST is only relevant to eligible graduating/entering-college students; funding/operation remains unconfirmed.
- May Keller BLOOM, academic-year UBRP/AMNH/SMRI, general coursework and standalone scholarships are documented in the audit rather than counted as summer research placements.
