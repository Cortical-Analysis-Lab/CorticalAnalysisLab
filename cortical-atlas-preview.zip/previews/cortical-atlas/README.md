Cortical Atlas Preview

Open index.html here to preview the seven lab pages. Existing site pages, shared styles, and production deployment are unchanged. The preview uses a separate stylesheet and the supplied cortical image. Fellowship database is outside this visual preview.
